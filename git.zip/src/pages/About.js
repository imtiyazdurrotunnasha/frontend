function About() {
  return (
    <div className="card">
      <div className="card-body">
        <h2>Tentang Saya</h2>
        <p>Halo! Nama saya <b>[Nama Kamu]</b>. Saya adalah pengembang web dengan keahlian frontend dan backend menggunakan React.js & Node.js.</p>
        <p>Saya tertarik dalam membangun aplikasi modern yang cepat dan responsif.</p>
      </div>
    </div>
  );
}

export default About;
